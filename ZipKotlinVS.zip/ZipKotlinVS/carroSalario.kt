// exercicio Carro x Salario
import kotlin.math.*

fun main(){
    var salario: Float = 5000f
    var contas: Float = 5000f

    var carro1: String = "Fusca"
     var carro2: String = "BMW"

     if(contas > salario){
        println("amem jesus")
     }else{
        println("lascou")
     }

     if(salario == contas){
        println("igual da p sobreviver")
     }else{
        println("diferente nao sei se e bom ou ruim")
     }

     if(carro1 == carro2){
        println("iguais (jesus)")
     }else{
        println("diferentes")
     }

}