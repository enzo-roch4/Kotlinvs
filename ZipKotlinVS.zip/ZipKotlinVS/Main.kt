package Aulas//fun main() {
//    println("Hello World!")
//}

//fun main(){
//    println("Digite seu nome:")
//    val nome = readLine()!!.toString()
//
//    println("Digite sua idade:")
//    val idade = readLine()!!.toInt()
//
//    println("Digite seu email:")
//    val email = readLine()!!.toString()
//
//    println("Ativo? (true or false)")
//    val status = readLine()!!.toBoolean()
//
//    println("ola, $nome, sua idade e $idade, email $email, esta ativo?: $status")
//
//}
//fun main(){
//
//    println("Digite a temperatura:")
//    val celsius = readLine()!!.toDouble()
//
//    var fahrenheit = ((celsius * 9)/5) + 32
//    var kelvin = celsius + 273.15
//
//    println("A temperatura em celsiu e: $celsius, em fahrenheit $fahrenheit e kelvin $kelvin ")
//
//}
//fun main(){
//
//    println("Digite a nota da Primeira avaliação:")
//    val nota1 = readLine()!!.toDouble()
//
//    println("Digite a nota da Segunda avaliação:")
//    val nota2 = readLine()!!.toDouble()
//
//    println("Digite a nota da Terceira avaliação:")
//    val nota3 = readLine()!!.toDouble()
//
//    val media = (nota1+nota2+nota3)/3
//    val medidaForatada = String.format("$.2f", media)
//    println("A media e $media")
//}
//fun main() {
//
//    var nota1 = 7.8
//    var nota2 = 8.2
//    var nota3 = 10
//    var media = (nota1+nota2+nota3)/3
//    println("A media e $media")
//}




